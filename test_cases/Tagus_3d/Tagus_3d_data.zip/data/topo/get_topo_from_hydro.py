import xarray as xr
import numpy as np

df = xr.open_dataset("./../hydro/tagus.20190626.nc")

# Save to netCDF
ds = xr.Dataset(
    data_vars={
        'bathymetry': (('lat', 'lon'), df.bathymetry.values),
    },
    coords={
        'lat': df.lat.values,
        'lon': df.lon.values,
    },
)
encoding = {"bathymetry": {"_FillValue": None},
            "lon": {"_FillValue": None},
            "lat": {"_FillValue": None}}
ds.to_netcdf('./topo.nc', encoding=encoding)
